void cmd_delete(char *cadena);
int cmd_deltree(const char *tr[]);