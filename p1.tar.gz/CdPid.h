#ifndef MAX_ENTRADA
#define MAX_ENTRADA 4096
void cmd_cd (char *cadena, char *trozos);
void cmd_pid(char * parm);
#endif