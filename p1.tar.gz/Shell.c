// Fabián Lema Pérez, Orlando Vázquez López 
//Grupo: 1.2
//Fecha: 02/11/2014
int main (){
 Entrada();
} 

