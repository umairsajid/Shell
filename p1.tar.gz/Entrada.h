#ifndef MAX_ENTRADA
#define MAX_ENTRADA 4096
#endif 